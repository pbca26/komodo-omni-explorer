const cmcCoinDetailsList = {
  NON_KMD_ASSETS: [
    'BET',
    'PGT',
    'DEX',
    'HODL',
    'MVP',
    'EQL',
    'CCL',
  ],
};

module.exports = cmcCoinDetailsList;
const config = {
  https: false,
  ip: '127.0.0.1',
  feedAPIPort: 8888,
  feedSourceIP: '94.130.108.82',
  feedSourcePort: 7782,
};

module.exports = config;
const config = require('./config');
const datafeed = require('./datafeed.js');

// const makeSymbols = require('./makeSymbols.js');
// uncomment and run once to make a new list of coin pairs

console.log(`Charts Server is running at ${config.ip}:${config.port}`);
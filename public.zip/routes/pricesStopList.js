const pricesStopList = [
  'BEER',
  'PIZZA',
  'MORTY',
  'RICK',
  'VOTE2019',
];

module.exports = pricesStopList;
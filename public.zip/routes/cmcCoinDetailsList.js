const cmcCoinDetailsList = {
  NON_KMD_ASSETS: [
    'BET',
    'PGT',
    'DEX',
    'HODL',
    'MVP',
    'EQL',
    'CCL',
    'OUR',
  ],
};

module.exports = cmcCoinDetailsList;
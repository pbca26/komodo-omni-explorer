const pricesStopList = [
  'BEER',
  'PIZZA',
  'MORTY',
  'RICK',
];

module.exports = pricesStopList;
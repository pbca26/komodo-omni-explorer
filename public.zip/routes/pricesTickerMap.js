const pricesTickerMap = {
  PIRATE: 'ARRR',
  OUR: 'OURC',
};

module.exports = pricesTickerMap;